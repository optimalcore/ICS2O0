lower = int(input("Choose a low number: "))
higher = int(input("Choose a high number: "))

for i in range(lower, higher + 1):
    print(i)

