numberList = ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"]
choice = input("Choose a number between one and ten: ")
index = int(choice) - 1
print("You chose " + numberList[index])

