for i in range(0, 21):
    print(i)

