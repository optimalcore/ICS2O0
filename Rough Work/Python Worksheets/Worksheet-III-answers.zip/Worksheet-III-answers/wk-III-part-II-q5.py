number = int(input("Choose a number between 0 and 20: "))

for i in range(0, int(number / 2) + 1):
    print(i * 2)

