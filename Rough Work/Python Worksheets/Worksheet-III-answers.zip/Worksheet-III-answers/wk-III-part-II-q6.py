number = int(input("Choose a number between 0 and 20: "))

for i in range(0, int((number + 1)/ 2)):
    print(i * 2 + 1)

