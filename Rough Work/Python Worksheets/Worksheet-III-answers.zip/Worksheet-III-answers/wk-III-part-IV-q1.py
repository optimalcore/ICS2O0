import turtle
jane = turtle.Pen()

for i in range(4):
    jane.forward(100)
    jane.left(90)

