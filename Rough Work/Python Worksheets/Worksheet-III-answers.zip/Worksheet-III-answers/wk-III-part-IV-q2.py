import turtle
jane = turtle.Pen()

for i in range(6):
    jane.forward(100)
    jane.left(140)
    jane.forward(100)
    jane.right(80)

