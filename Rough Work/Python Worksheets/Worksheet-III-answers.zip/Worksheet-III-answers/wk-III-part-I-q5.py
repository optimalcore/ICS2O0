number = input("Choose a number: ")
print(number + " times 10 is " + str(int(number) * 10))
