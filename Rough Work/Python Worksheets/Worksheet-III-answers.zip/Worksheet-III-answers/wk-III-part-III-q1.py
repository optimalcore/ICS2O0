shoppingList = []

print("Please add 5 items to your shopping list.")

for i in range(5):
    item = input("Add item: ")
    shoppingList.append(item)

print("You have added the following items to your shopping list:")
print(shoppingList)

