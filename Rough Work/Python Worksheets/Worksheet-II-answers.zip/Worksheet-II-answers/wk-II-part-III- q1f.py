import turtle
myPen = turtle.Pen()

myPen.color("red")
myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)

myPen.color("blue")
myPen.right(45)
myPen.circle(70.7)

