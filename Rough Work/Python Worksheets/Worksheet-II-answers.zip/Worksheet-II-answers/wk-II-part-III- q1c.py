import turtle
myPen = turtle.Pen()

myPen.color("red")
myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)

myPen.forward(50)
myPen.color("blue")
myPen.circle(50)

