import turtle
myPen = turtle.Pen()

myPen.forward(40)
myPen.left(90)
myPen.forward(20)
myPen.left(90)
myPen.forward(40)
myPen.right(90)

myPen.forward(40)
myPen.left(90)
myPen.forward(20)
myPen.left(90)
myPen.forward(40)
myPen.right(90)

myPen.forward(40)
myPen.left(90)
myPen.forward(20)
myPen.left(90)
myPen.forward(40)
myPen.right(90)

myPen.forward(40)
myPen.left(90)
myPen.forward(20)
myPen.left(90)
myPen.forward(40)
myPen.right(90)

