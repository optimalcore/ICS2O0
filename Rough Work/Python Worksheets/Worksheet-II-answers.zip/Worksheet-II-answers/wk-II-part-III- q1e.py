import turtle
myPen = turtle.Pen()

myPen.forward(100)
myPen.left(140)
myPen.forward(100)
myPen.right(80)

myPen.forward(100)
myPen.left(140)
myPen.forward(100)
myPen.right(80)

myPen.forward(100)
myPen.left(140)
myPen.forward(100)
myPen.right(80)

myPen.forward(100)
myPen.left(140)
myPen.forward(100)
myPen.right(80)

myPen.forward(100)
myPen.left(140)
myPen.forward(100)
myPen.right(80)

myPen.forward(100)
myPen.left(140)
myPen.forward(100)
myPen.right(80)


