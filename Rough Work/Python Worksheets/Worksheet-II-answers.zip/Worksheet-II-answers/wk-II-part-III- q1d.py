import turtle
myPen = turtle.Pen()

myPen.width(5)
myPen.right(45)
myPen.forward(100)

myPen.up()
myPen.left(135)
myPen.forward(70.7)
myPen.left(135)
myPen.down()

myPen.forward(100)

