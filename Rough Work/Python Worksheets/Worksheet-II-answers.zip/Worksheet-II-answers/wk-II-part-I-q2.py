name = input("Hello, welcome to Snappy Jacks. What name is your booking under? ")
number = input("Hi, " + name + "! How many people will be attneding today? ")
print("Ok " + name + ", I'll see if I can find a table for " + number)
