import turtle
myPen = turtle.Pen()

myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)
myPen.forward(100)
myPen.left(90)
